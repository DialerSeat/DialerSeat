'use client'
import dynamic from 'next/dynamic'
import type { AppDefinition } from './types'

// =============================================================================
// APP REGISTRY
// =============================================================================
// Single source of truth for what apps exist on the desktop. The Desktop
// component reads this to render icons; the WindowManager reads it to mount
// the right component when a window opens.
//
// Components are lazy-loaded via next/dynamic so the desktop shell itself
// stays small. Each app file lives in its own folder under apps/.
//
// ADDING A NEW APP:
//   1. Create components/admin-desktop/apps/<name>/index.tsx with default export
//   2. Import lazily here
//   3. Add an APP entry below (set visibleTo if managers should see it)
//   That's it — the desktop picks it up automatically.
//   FOR A DOWNLOADABLE (App Store) APP: also add its id to STORE_APP_IDS in
//   desktopServices.tsx — it then hides from the desktop until downloaded.
//
// v23 CHANGES:
//   - Added `support` — the admin Support app (support / bug / exit feed).
//     Admin-only base app: always installed, shows on the admin desktop. Backs
//     onto /api/admin/support (read/respond) + /api/support/submit (user posts).
//
// v22 CHANGES:
//   - Added `visibleTo` per app. ONE desktop, ONE registry, driven by a role.
//     visibleTo = which roles SEE the app (omitted = admin-only). This is the
//     single switch that keeps the admin and manager desktops in lockstep:
//     change an app here and both roles pick it up the same second.
//     v1 manager-visible apps: analytics, teams, notes (data scoped per role
//     in each app's API). Everything else stays admin-only — logs/numbers/
//     whitelabel/overview/gmail/browser/appstore/clerk-profile. As the
//     tenant-scoped Branding and Billing apps get built, flip their visibleTo.
//
// v21 CHANGES:
//   - Added `appstore` — the App Store (Desktop v24). BASE app: removable
//     from the homescreen, never uninstallable, permanently pinned in the
//     Start menu.
//
// v20 CHANGES:
//   - Removed `view-landing` — replaced by a system-tray icon in Taskbar
//   - Added `logs` — purchases + renewals + cancels timeline
//   - Added `notes` — iCloud-style sidebar + editor, Supabase-backed
// =============================================================================

const DashboardApp = dynamic(() => import('./apps/Dashboard'), {
  loading: () => <AppLoading />,
  ssr: false,
})
const AnalyticsApp = dynamic(() => import('./apps/Analytics'), {
  loading: () => <AppLoading />,
  ssr: false,
})
const OverviewApp = dynamic(() => import('./apps/Overview'), {
  loading: () => <AppLoading />,
  ssr: false,
})
const TeamsApp = dynamic(() => import('./apps/Teams'), {
  loading: () => <AppLoading />,
  ssr: false,
})
const NumbersApp = dynamic(() => import('./apps/Numbers'), {
  loading: () => <AppLoading />,
  ssr: false,
})
const WhiteLabelApp = dynamic(() => import('./apps/WhiteLabel'), {
  loading: () => <AppLoading />,
  ssr: false,
})
const LogsApp = dynamic(() => import('./apps/Logs'), {
  loading: () => <AppLoading />,
  ssr: false,
})
const SupportApp = dynamic(() => import('./apps/Support'), {
  loading: () => <AppLoading />,
  ssr: false,
})
const NotesApp = dynamic(() => import('./apps/Notes'), {
  loading: () => <AppLoading />,
  ssr: false,
})
const GmailApp = dynamic(() => import('./apps/Gmail'), {
  loading: () => <AppLoading />,
  ssr: false,
})
const ClerkProfileApp = dynamic(() => import('./apps/ClerkProfile'), {
  loading: () => <AppLoading />,
  ssr: false,
})
const BrowserApp = dynamic(() => import('./apps/Browser'), {
  loading: () => <AppLoading />,
  ssr: false,
})
const AppStoreApp = dynamic(() => import('./apps/AppStore'), {
  loading: () => <AppLoading />,
  ssr: false,
})

function AppLoading() {
  return (
    <div style={{
      display: 'flex', alignItems: 'center', justifyContent: 'center',
      width: '100%', height: '100%',
      background: '#f5f9fd',
      fontFamily: '"Segoe UI", Tahoma, sans-serif',
      fontSize: 12, color: '#5a5e6a', letterSpacing: 1,
    }}>
      Loading...
    </div>
  )
}

export const APPS: AppDefinition[] = [
  {
    // Manager-only base app — returns to /dashboard. Listed FIRST so it's the
    // top-left default icon on the manager desktop (movable like any other).
    // Admin never sees it (visibleTo manager only).
    id: 'dashboard',
    name: 'Dashboard',
    icon: '🏠',
    iconBg: 'linear-gradient(135deg, #4a9eff, #2a6eff)',
    description: 'Return to your main dashboard',
    visibleTo: ['manager'],
    Component: DashboardApp,
    defaultSize: { width: 480, height: 320 },
  },
  {
    id: 'analytics',
    name: 'Analytics',
    icon: '📊',
    iconBg: 'linear-gradient(135deg, #4a9eff, #2a6eff)',
    description: 'Business KPIs, revenue, signups, churn',
    visibleTo: ['admin', 'manager'],
    Component: AnalyticsApp,
    defaultSize: { width: 1080, height: 720 },
  },
  {
    id: 'overview',
    name: 'Overview',
    icon: '👥',
    iconBg: 'linear-gradient(135deg, #5ad17a, #1a6a1a)',
    description: 'All platform users with status and delete',
    visibleTo: ['admin'],
    Component: OverviewApp,
    defaultSize: { width: 1000, height: 720 },
  },
  {
    id: 'teams',
    name: 'Teams',
    icon: '🏢',
    iconBg: 'linear-gradient(135deg, #ffaa3e, #d07020)',
    description: 'Every team on the platform with members and seats',
    visibleTo: ['admin', 'manager'],
    Component: TeamsApp,
    defaultSize: { width: 1100, height: 720 },
  },
  {
    id: 'numbers',
    name: 'Numbers',
    icon: '☎️',
    iconBg: 'linear-gradient(135deg, #b478ff, #6a30d0)',
    description: 'Outbound number pool, buy, register, release',
    visibleTo: ['admin'],
    Component: NumbersApp,
    defaultSize: { width: 1180, height: 760 },
  },
  {
    id: 'whitelabel',
    name: 'White Label',
    shortName: 'WL',
    icon: '🏷️',
    iconBg: 'linear-gradient(135deg, #ff6464, #c02020)',
    description: 'Tenant CRUD, branding editor, team impersonation',
    visibleTo: ['admin'],
    Component: WhiteLabelApp,
    defaultSize: { width: 1200, height: 760 },
  },
  {
    id: 'logs',
    name: 'Logs',
    icon: '🧾',
    iconBg: 'linear-gradient(135deg, #ffd96a, #c48a1a)',
    description: 'Purchases, renewals, and cancels across all customers',
    visibleTo: ['admin'],
    Component: LogsApp,
    defaultSize: { width: 1000, height: 700 },
  },
  {
    // Admin Support app — support / bug / exit submissions feed. Admin-only
    // base app (always installed, shows on the admin desktop). Reads/responds
    // via /api/admin/support; users post via /api/support/submit.
    id: 'support',
    name: 'Support',
    icon: '🎧',
    iconBg: 'linear-gradient(135deg, #4a9eff, #6a4aff)',
    description: 'User support queries, bug reports, and exit feedback',
    visibleTo: ['admin'],
    Component: SupportApp,
    defaultSize: { width: 1100, height: 720 },
  },
  {
    id: 'notes',
    name: 'Notes',
    icon: '📝',
    iconBg: 'linear-gradient(135deg, #ffe27a, #d4a020)',
    description: 'Private scratchpad — auto-saved. Only you can see its data.',
    visibleTo: ['admin', 'manager'],
    Component: NotesApp,
    defaultSize: { width: 1000, height: 700 },
  },
  {
    id: 'gmail',
    name: 'Gmail',
    icon: '✉',
    iconBg: 'linear-gradient(135deg, #ea4335, #b8281a)',
    description: 'Read, send, and manage your DialerSeat business inbox',
    visibleTo: ['admin'],
    Component: GmailApp,
    defaultSize: { width: 1100, height: 720 },
  },
  {
    id: 'browser',
    name: 'Browser',
    icon: '🌐',
    iconBg: 'linear-gradient(135deg, #5dd5d5, #2a8a8a)',
    description: 'Open web pages (embeds where allowed, opens in tab otherwise)',
    visibleTo: ['admin'],
    Component: BrowserApp,
    defaultSize: { width: 1024, height: 720 },
  },
  {
    // Not shown as a desktop icon by default — opened from the tray/StartMenu.
    // Account management is identical for both roles, so it's visible to both.
    id: 'clerk-profile',
    name: 'Account',
    icon: '👤',
    iconBg: 'linear-gradient(135deg, #b478ff, #6a30d0)',
    description: 'Manage your DialerSeat account',
    visibleTo: ['admin', 'manager'],
    Component: ClerkProfileApp,
    defaultSize: { width: 920, height: 720 },
  },
  {
    // BASE app — removable from the homescreen, never uninstallable. The
    // Start menu pins it permanently so it can always re-add hidden apps.
    // Visible to both roles so managers can manage their own desktop apps.
    id: 'appstore',
    name: 'App Store',
    icon: '🛍️',
    iconBg: 'linear-gradient(135deg, #2a4a8a, #4a9eff)',
    description: 'Browse, download, and manage desktop apps',
    visibleTo: ['admin', 'manager'],
    Component: AppStoreApp,
    defaultSize: { width: 880, height: 620 },
  },
]

export function getApp(id: string): AppDefinition | undefined {
  return APPS.find(a => a.id === id)
}